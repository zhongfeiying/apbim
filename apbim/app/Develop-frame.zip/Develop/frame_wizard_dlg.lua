__ENV = module_seeall(...,package.seeall)

local iup = require'iuplua'


local empty_tog_ = iup.toggle{title="Empty",expand='Yes'}
local hello_tog_ = iup.toggle{title="Hello World",expand='Yes'}
local paint_tog_ = iup.toggle{title="Paint",expand='Yes'}
local menu_tog_ = iup.toggle{title="Menu",expand='Yes'}
local toolbar_tog_ = iup.toggle{title="Toolbar",expand='Yes'}
local type_rad_ = iup.radio{iup.vbox{empty_tog_;hello_tog_;paint_tog_;menu_tog_;toolbar_tog_;};};

local geometry_tog_ = iup.toggle{title="Geometry",expand='Yes'}
local model_tog_ = iup.toggle{title="Model",expand='Yes'}
local cmd_tog_ = iup.toggle{title="Command",expand='Yes'}
local steel_tog_ = iup.toggle{title="Steel",expand='Yes'}

local path_lab_ = iup.label{title="Folder:",size="30X"};
local path_txt_ = iup.text{expand="Horizontal",value=""};
local browse_btn_ = iup.button{title="...",rastersize='30x'};
local ok_btn_ = iup.button{title="OK",rastersize='100x'};
local cancel_btn_ = iup.button{title="Cancel",rastersize='100x'};

local dlg_ = iup.dialog{
	title = 'Frame Wizard';
	margin = '5x5';
	rastersize = '480X';
	iup.vbox{
		iup.frame{
			iup.vbox{
				iup.hbox{path_lab_,path_txt_,browse_btn_};
				iup.hbox{
					iup.frame{
						title = 'Sample';
						type_rad_;
					};
					iup.frame{
						title = 'Foundation';
						iup.vbox{geometry_tog_;model_tog_;cmd_tog_;steel_tog_;};
					};
				};
			};
		};
		iup.hbox{iup.fill{},ok_btn_,cancel_btn_};
	};
};

local function copy_empty(path)
	require'sys.api.dos'.copy('*.exe',path);
	require'sys.api.dos'.copy('*.dll',path);
end

empty_tog_.cbf = function(path)
	copy_empty(path);
	require'sys.api.dos'.copy('app\\Develop\\frame_wizard\\empty.lua',path..'main.lua');
end

hello_tog_.cbf = function(path)
	copy_empty(path);
	require'sys.api.dos'.copy('app\\Develop\\frame_wizard\\hello.lua',path..'main.lua');
end

paint_tog_.cbf = function(path)
	copy_empty(path);
	require'sys.api.dos'.copy('app\\Develop\\frame_wizard\\paint.lua',path..'main.lua');
end

menu_tog_.cbf = function(path)
	copy_empty(path);
	require'sys.api.dos'.copy('app\\Develop\\frame_wizard\\menu.lua',path..'main.lua');
end

toolbar_tog_.cbf = function(path)
	copy_empty(path);
	require'sys.api.dos'.copy('app\\Develop\\frame_wizard\\toolbar.lua',path..'main.lua');
	require'sys.api.dos'.copy('app\\Develop\\frame_wizard\\toolbar.bmp',path);
end

local function on_ok()
	local path = path_txt_.value;
	if not path or path=='' then return end
	local tog = type_rad_.value;
	if tog and type(tog.cbf)=='function' then tog.cbf(path) end
	require'sys.api.dos'.start(path);
	dlg_:hide();
end

local function on_cancel()
	dlg_:hide();
end

function ok_btn_:action()
	on_ok();
end

function cancel_btn_:action()
	on_cancel();
end

function browse_btn_:action()
	local str = require'sys.iup'.open_dir_dlg{};
	if not str or str=='' then return end
	path_txt_.value = str;
end

function pop()
	dlg_:show();
end

require'sys.api.iup.key'.register_k_any{dlg=dlg_,[iup.K_CR]=on_ok,[iup.K_ESC]=on_cancel};
