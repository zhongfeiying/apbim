_ENV=module_seeall(...,package.seeall)

local function App_Wizard(sc)
	require"app.Develop.app_wizard_dlg".pop(sc);
end

local function Frame_Wizard(sc)
	require"app.Develop.frame_wizard_dlg".pop(sc);
end

local function Message(sc)
	require"app.Develop.msg_dlg".pop(sc);
end


function load()
	require"sys.menu".add{frame=true,view=true,pos={"Window"},name={"Tools","Develop","App Wizard"},f=App_Wizard};
	-- require"sys.menu".add{frame=true,view=true,pos={"Window"},name={"Tools","Develop","Class Wizard"},f=App_Wizard};
	require"sys.menu".add{frame=true,view=true,pos={"Window"},name={"Tools","Develop","Frame Wizard"},f=Frame_Wizard};
end



