_ENV=module_seeall(...,package.seeall)

local iup = require"iuplua"

local app_label_ = iup.label{title="Name:",size="30X"};
local app_text_ = iup.text{expand="Horizontal",value="NewApp"};
local app_cb_all_ = iup.list{expand="Yes","on_load()","on_init()"};
local new_app_ = iup.button{title="Create",size="60X15"};

local empty_tog_ = iup.toggle{title="Empty",expand='Yes'}
local sample_tog_ = iup.toggle{title="Sample",expand='Yes'}
local type_rad_ = iup.radio{iup.vbox{empty_tog_;sample_tog_;};};

local ok_ = iup.button{title="OK",size="60X15"};
local cancel_ = iup.button{title="Close",size="60X15"};

local dlg_ = iup.dialog{
	title = "App Wizard";
	rastersize = "480X"; 
	iup.tabs{
		iup.vbox{
			tabtitle = "App";
			iup.frame{
				title = "App:";
				iup.vbox{
					iup.hbox{app_label_,app_text_};
					iup.frame{
						title="Callback function:";
						iup.hbox{app_cb_all_};
					};
					type_rad_;
					iup.hbox{iup.fill{},ok_};
				};
			};
		};
	};
	alignment="ARight";
	margin="10x10";
};

local function read_file(pathname)
	local f = io.open(pathname,"r");
	if not f then return end
	local str = f:read('*all');
	f:close();
	return str;
end

local function write_file(pathname,str)
	local f = io.open(pathname,"w");
	if not f then return end
	f:write(str);
	f:close();
end

local function create_app_folder(name)
	local path = "app\\"..name.."\\";
	require"sys.api.dir".create_folder(path)
	return true
end

local function create_app_main_file(name)
	local old = "app\\Develop\\app_wizard\\main.lua";
	local new = "app\\"..name.."\\main.lua";
	local str = read_file(old);
	local str = string.gsub(str,'_APP_',name);
	write_file(new,str);
end

local function create_app_function_file(name,type)
	local old = "app\\Develop\\app_wizard\\function_"..type..".lua";
	local new = "app\\"..name.."\\function.lua";
	local str = read_file(old);
	local str = string.gsub(str,'_APP_',name);
	write_file(new,str);
end

local function create_class_file(name,type)
	local old = "app\\Develop\\app_wizard\\Solid_"..type..".lua";
	local new = "app\\"..name.."\\Solid.lua";
	local str = read_file(old);
	local str = string.gsub(str,'_APP_',name);
	write_file(new,str);
end

local function create_dlg_file(name,type)
	local old = "app\\Develop\\app_wizard\\Solid_dlg_"..type..".lua";
	local new = "app\\"..name.."\\Solid_dlg.lua";
	local str = read_file(old);
	local str = string.gsub(str,'_APP_',name);
	write_file(new,str);
end

function new_app_:action()
	create_app();
end

empty_tog_.cbf = function(name)
	create_app_folder(name)
	create_app_main_file(name);
	create_app_function_file(name,'empty');
end

sample_tog_.cbf = function(name)
	create_app_folder(name)
	create_app_main_file(name);
	create_app_function_file(name,'sample');
	create_class_file(name,'sample');
	create_dlg_file(name,'sample');
end

local function on_ok()
	local name = tostring(app_text_.value);
	if not name or name=='' then iup.Alarm("Warning","Input New Name","OK") return end
	local tog = type_rad_.value;
	if tog and type(tog.cbf)=='function' then tog.cbf(name) end
	dlg_:hide();
end


function ok_:action()
	on_ok();
	-- dlg_:hide();
end

function cancel_:action()
	dlg_:hide();
end

function pop(sc)
	dlg_:show();
end
