_ENV=module_seeall(...,package.seeall)

local function Draw_Solid(sc)
	sc = sc or require"sys.mgr".new_scene();
	_G.package.loaded["app._APP_.Solid"] = nil;
	require"sys.cmd".set{command=require"app.Edit.Create".new{class=require"app._APP_.Solid".Class:new{Color={0,0,255}}:set_mode_rendering()}};
end

function load()
	require"sys.menu".add{app="_APP_",frame=true,view=true,pos={"Window"},name={"_APP_","Draw","Solid"},f=Draw_Solid};
end
