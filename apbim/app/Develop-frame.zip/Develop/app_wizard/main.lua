_ENV=module_seeall(...,package.seeall)

function on_load()
	_G.package.loaded["app._APP_.function"] = nil;
	require"app._APP_.function".load();
end

function on_init()
end


