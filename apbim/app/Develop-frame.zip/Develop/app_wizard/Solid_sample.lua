_ENV=module_seeall(...,package.seeall)

Class = {
	Classname = "app/_APP_/Solid";
};
require"sys.Entity".Class:met(Class);

function Class:on_edit()
	require'app._APP_/Solid_dlg'.pop();
end

function Class:on_write_info()
	self:add_info_text("Classname",self.Classname);
	self:add_info_text("Type",self.Type);
	self:add_info_text("Date",self:get_date_text());
	self:add_info_text("Color",require"sys.text".color(self.Color));
	self:add_info_text("Point",require"sys.text".array(self:get_pt(1)));
end

function Class:on_draw_diagram()
	local cr = require"sys.geometry".Color:new(self.Color):get_gl()
	local pt1 = self:get_pt(1);
	local pt2 = self:get_pt(2);
	local pts = {
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt1.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt1.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt2.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt2.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt1.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt1.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt2.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt2.y,pt2.z+2000};
	};
	self:set_shape_wireframe{
		surfaces = {
			{
				points = pts;
				lines = {{1,7},{2,8},{3,5},{4,6}};
			};
		};
	};
end

function Class:on_draw_wireframe()
	local cr = require"sys.geometry".Color:new(self.Color):get_gl()
	local pt1 = self:get_pt(1);
	local pt2 = self:get_pt(2);
	local pts = {
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt1.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt1.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt2.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt2.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt1.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt1.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt2.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt2.y,pt2.z+2000};
	};
	self:set_shape_wireframe{
		surfaces = {
			{
				points = pts;
				lines = {{1,2},{2,3},{3,4},{4,1},{5,6},{6,7},{7,8},{8,5},{1,5},{2,6},{3,7},{4,8}};
			};
		};
	};
end

function Class:on_draw_rendering()
	local cr = require"sys.geometry".Color:new(self.Color):get_gl()
	local pt1 = self:get_pt(1);
	local pt2 = self:get_pt(2);
	local pts = {
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt1.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt1.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt2.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt2.y,pt1.z-2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt1.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt1.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt2.x,pt2.y,pt2.z+2000};
			{cr.r,cr.g,cr.b,1,1,pt1.x,pt2.y,pt2.z+2000};
	};
	self:set_shape_rendering{
		surfaces = {
			{points = pts,outer = {4,3,2,1}};
			{points = pts,outer = {5,6,7,8}};
			-- {points = pts,outer = {1,2,6,5}};
			-- {points = pts,outer = {2,3,7,6}};
			-- {points = pts,outer = {3,4,8,7}};
			-- {points = pts,outer = {4,1,5,8}};
		};
	};
end

