_ENV=module_seeall(...,package.seeall)

local iup = require"iuplua";

local color_lab_ = iup.label{title="Color:",rastersize="50X"};
local color_r_lab_ = iup.label{title="R="};
local color_r_txt_ = iup.text{expand="Horizontal",rastersize="50X"};
local color_g_lab_ = iup.label{title="G="};
local color_g_txt_ = iup.text{expand="Horizontal",rastersize="50X"};
local color_b_lab_ = iup.label{title="B="};
local color_b_txt_ = iup.text{expand="Horizontal",rastersize="50X"};

local modify_ = iup.button{title="Modify",rastersize="100X30"};
local ok_ = iup.button{title="OK",rastersize="100X30"};
local cancel_ = iup.button{title="Cancel",rastersize="100X30"};

local dlg_ = iup.dialog{
	title = "Property";
	resize = "NO";
	rastersize = "500x";
	margin = "5x5";
	iup.vbox{
		iup.frame{
			iup.vbox{
				iup.hbox{color_lab_,color_r_lab_,color_r_txt_,color_g_lab_,color_g_txt_,color_b_lab_,color_b_txt_};
			};
		};
		iup.hbox{modify_,ok_,cancel_};
		alignment="aRight";
	};
};

local function init()
	local cur = require'sys.mgr'.cur();
	if type(cur)~='table' then return end
	local cr = require"sys.View".get_color(require"sys.mgr".get_cur_scene(),cur.mgrid) or cur.Color;
	color_r_txt_.value = cr.r;
	color_g_txt_.value = cr.g;
	color_b_txt_.value = cr.b;
end

local function modify()
	local s = require'sys.mgr'.curs();
	if type(s)~='table' then return end
	for k,v in pairs(s) do
		local r = color_r_txt_.value;
		local g = color_g_txt_.value;
		local b = color_b_txt_.value;
		require"sys.View".set_color(require"sys.mgr".get_cur_scene(),k,{r,g,b});
		require"sys.mgr".redraw(v);
	end
	require"sys.mgr".update();
end

function modify_:action()
	modify();
end

function ok_:action()
	modify();
	dlg_:hide();
end

function cancel_:action()
	dlg_:hide();
end

function pop()
	init();
	dlg_:show();
end

