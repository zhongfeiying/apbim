local gl = require "luaext.gl"

function get_obj()
	local l,w,h = 1000,1000,1000;
	local d = 200;
	local r,g,b = 0,0,1;
	local u,v = 2,2;
	local x,y,z = 0,0,0;
	local obj = {
		index = 1;
		surfaces = {
			{
				textured = 0;
				points = {
					{r+0.5,g,b,0,0,x,y,z};
					{r+0.5,g,b,0,0,x+l,y,z};
					{r+0.5,g,b,0,0,x+l,y+w,z};
					{r+0.5,g,b,0,0,x,y+w,z};
				};
				outer = {1,2,3,4};
			};
			{
				textured = 0;
				points = {
					{r+0.5,g,b,0,0,x,y,z};
					{r+0.5,g,b,0,0,x+l,y,z};
					{r,g+0.5,b,0,0,x+l,y,z+h};
					{r,g+0.5,b,0,0,x,y,z+h};
				};
				outer = {1,2,3,4};
			};
			{
				textured = 0;
				points = {
					{r+0.5,g,b,0,0,x,y+w,z};
					{r+0.5,g,b,0,0,x+l,y+w,z};
					{r,g,b-0.5,0,0,x+l,y+w,z+h};
					{r,g,b-0.5,0,0,x,y+w,z+h};
				};
				outer = {1,2,3,4};
			};
			{
				textured = 0;
				points = {
					{r,g,b,0,0,x,y,z+h};
					{r,g,b,u,0,x+l,y,z+h};
					{r,g,b,u,v,x+l,y+w,z+h};
					{r,g,b,0,v,x,y+w,z+h};
					{r,g,b,0,0,x+d,y+d,z+h};
					{r,g,b,u,0,x+l-d,y+d,z+h};
					{r,g,b,u,v,x+l-d,y+w-d,z+h};
					{r,g,b,0,v,x+d,y+w-d,z+h};
				};
				outer = {1,2,3,4};
				inners = {{5,6,7,8}};
			};
			{
				textured = 0;
				points = {
					{r,g,b,0,0,x,y,z};
					{r,g,b,0,0,x+l,y,z};
					{r,g,b,0,0,x+l,y+w,z};
					{r,g,b,0,0,x,y+w,z};
					{r,g,b,0,0,x,y,z+h};
					{r,g,b,0,0,x+l,y,z+h};
					{r,g,b,0,0,x+l,y+w,z+h};
					{r,g,b,0,0,x,y+w,z+h};
				};
				lines = {
					{1,2};{2,3};{3,4};{4,1};
					{5,6};{6,7};{7,8};{8,5};
					{1,5};{2,6};{3,7};{4,8};
				};
			};
			{
				textured = 0;
				points = {
					{0,0,0,0,0,x+l,y+w,z+h};
				};
				texts = {
					{ptno=1,r=1,g=0,b=0.5,str="This is a solid."};
				};
			};
		};
	};
	return obj;
end

function to_3d(sc)
	local t = get_scene_t(sc);
	t.clip.x.x = 1;
	t.clip.x.y = 0;
	t.clip.x.z = 0;
	t.clip.z.x = 0;
	t.clip.z.y = 0;
	t.clip.z.z = 1;
	t.rotate.x = 0;
	t.rotate.y = 0;
	t.rotate.z = 0;
	t.matrix = {0.9,-0.2,0.35,0,0.4,0.4,-0.8,0,0,0.9,0.5,0,0,0,0,1};
	t.ortho = 0;
	set_scene_t(sc,t);
	return sc;
end

local sc = new_child(frm,"New1");
to_3d(sc)
local objs = {}
local obj1 = get_obj()
local glid = makelist(sc,obj1);
objs[obj1.index] = glid;

function render_objs(sc)
	for k,v in pairs(objs) do
		gl.glLoadName(k)
		gl.glCallList(v)
	end
end

function frmclose()
	for k,v in pairs(objs) do
		gl.glDeleteLists(v,1)
	end
end

function on_mousemove(scene,flags,x,y)end
function on_keydown(scene)end
function on_paint(scene)end
